read_verilog -sv {C:/Users/wee/AppData/Local/Temp/claude/D--115-1-embedded-sys-midterm-report/0ab647fd-9b9f-46c9-8993-886b1139c5f2/scratchpad/upstream/mvu_v0.10.1/mvu_4sx4u.sv}
read_verilog -sv {C:/Users/wee/AppData/Local/Temp/claude/D--115-1-embedded-sys-midterm-report/0ab647fd-9b9f-46c9-8993-886b1139c5f2/scratchpad/upstream/mvu_v0.10.1/mvu_8sx8u_dsp48.sv}
read_verilog -sv {C:/Users/wee/AppData/Local/Temp/claude/D--115-1-embedded-sys-midterm-report/0ab647fd-9b9f-46c9-8993-886b1139c5f2/scratchpad/upstream/mvu_v0.10.1/mvu_vvu_8sx9_dsp58.sv}
read_verilog -sv {C:/Users/wee/AppData/Local/Temp/claude/D--115-1-embedded-sys-midterm-report/0ab647fd-9b9f-46c9-8993-886b1139c5f2/scratchpad/upstream/mvu_v0.10.1/mvu_vvu_axi.sv}
read_verilog -sv {C:/Users/wee/AppData/Local/Temp/claude/D--115-1-embedded-sys-midterm-report/0ab647fd-9b9f-46c9-8993-886b1139c5f2/scratchpad/upstream/mvu_v0.10.1/replay_buffer.sv}
read_verilog {D:/vw3/d1_02_MVAU_rtl_0/MVAU_rtl_0_wrapper.v}
synth_design -top MVAU_rtl_0 -part xc7z020clg400-1 -mode out_of_context
report_utilization -file vivado_util.rpt
create_clock -period 8.000 -name ap_clk [get_ports ap_clk]
report_power -file vivado_power.rpt
