read_verilog -sv {D:/vw3/d0_19_ConvolutionInputGenerator_rtl_4/swg_pkg.sv}
read_verilog -sv {D:/vw3/d0_19_ConvolutionInputGenerator_rtl_4/ConvolutionInputGenerator_rtl_4_impl.sv}
read_verilog -sv {D:/vw3/d0_19_ConvolutionInputGenerator_rtl_4/swg_common.sv}
read_verilog {D:/vw3/d0_19_ConvolutionInputGenerator_rtl_4/ConvolutionInputGenerator_rtl_4_wrapper.v}
synth_design -top ConvolutionInputGenerator_rtl_4 -part xc7z020clg400-1 -mode out_of_context
report_utilization -file vivado_util.rpt
create_clock -period 8.000 -name ap_clk [get_ports ap_clk]
report_power -file vivado_power.rpt
