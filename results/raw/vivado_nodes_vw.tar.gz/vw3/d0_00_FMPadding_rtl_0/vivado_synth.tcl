read_verilog -sv {D:/vw3/d0_00_FMPadding_rtl_0/axi2we.sv}
read_verilog -sv {D:/vw3/d0_00_FMPadding_rtl_0/fmpadding.sv}
read_verilog -sv {D:/vw3/d0_00_FMPadding_rtl_0/fmpadding_axi.sv}
read_verilog {D:/vw3/d0_00_FMPadding_rtl_0/FMPadding_rtl_0.v}
synth_design -top FMPadding_rtl_0 -part xc7z020clg400-1 -mode out_of_context
report_utilization -file vivado_util.rpt
create_clock -period 8.000 -name ap_clk [get_ports ap_clk]
report_power -file vivado_power.rpt
