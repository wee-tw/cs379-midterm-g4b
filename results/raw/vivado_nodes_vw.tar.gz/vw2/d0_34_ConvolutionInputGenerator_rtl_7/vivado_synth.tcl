read_verilog -sv {D:/vw2/d0_34_ConvolutionInputGenerator_rtl_7/swg_pkg.sv}
read_verilog -sv {D:/vw2/d0_34_ConvolutionInputGenerator_rtl_7/ConvolutionInputGenerator_rtl_7_impl.sv}
read_verilog -sv {D:/vw2/d0_34_ConvolutionInputGenerator_rtl_7/swg_common.sv}
read_verilog {D:/vw2/d0_34_ConvolutionInputGenerator_rtl_7/ConvolutionInputGenerator_rtl_7_wrapper.v}
synth_design -top ConvolutionInputGenerator_rtl_7 -part xc7z020clg400-1 -mode out_of_context
report_utilization -file vivado_util.rpt
create_clock -period 10.000 -name ap_clk [get_ports ap_clk]
report_power -file vivado_power.rpt
