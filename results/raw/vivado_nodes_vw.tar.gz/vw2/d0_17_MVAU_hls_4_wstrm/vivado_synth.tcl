read_verilog -sv {D:/vw2/d0_17_MVAU_hls_4_wstrm/memstream.sv}
read_verilog -sv {D:/vw2/d0_17_MVAU_hls_4_wstrm/memstream_axi.sv}
read_verilog {D:/vw2/d0_17_MVAU_hls_4_wstrm/Q_srl.v}
read_verilog {D:/vw2/d0_17_MVAU_hls_4_wstrm/axilite_if.v}
read_verilog {D:/vw2/d0_17_MVAU_hls_4_wstrm/memstream_axi_wrapper.v}
read_verilog {D:/vw2/d0_17_MVAU_hls_4_wstrm/wstrm_top.v}
synth_design -top wstrm_top -part xc7z020clg400-1 -mode out_of_context
report_utilization -file vivado_util.rpt
create_clock -period 10.000 -name ap_clk [get_ports ap_clk]
report_power -file vivado_power.rpt
