read_verilog -sv {D:/vw2/d0_18_FMPadding_rtl_4/axi2we.sv}
read_verilog -sv {D:/vw2/d0_18_FMPadding_rtl_4/fmpadding.sv}
read_verilog -sv {D:/vw2/d0_18_FMPadding_rtl_4/fmpadding_axi.sv}
read_verilog {D:/vw2/d0_18_FMPadding_rtl_4/FMPadding_rtl_4.v}
synth_design -top FMPadding_rtl_4 -part xc7z020clg400-1 -mode out_of_context
report_utilization -file vivado_util.rpt
create_clock -period 10.000 -name ap_clk [get_ports ap_clk]
report_power -file vivado_power.rpt
