read_verilog -sv {D:/vw2/d0_11_Thresholding_rtl_0/thresholding.sv}
read_verilog -sv {D:/vw2/d0_11_Thresholding_rtl_0/thresholding_axi.sv}
read_verilog {D:/vw2/d0_11_Thresholding_rtl_0/Thresholding_rtl_0_axi_wrapper.v}
read_verilog {D:/vw2/d0_11_Thresholding_rtl_0/axilite_if.v}
synth_design -top Thresholding_rtl_0_axi_wrapper -part xc7z020clg400-1 -mode out_of_context
report_utilization -file vivado_util.rpt
create_clock -period 10.000 -name ap_clk [get_ports ap_clk]
report_power -file vivado_power.rpt
