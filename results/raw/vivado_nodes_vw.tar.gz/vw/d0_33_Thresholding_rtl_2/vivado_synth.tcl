read_verilog -sv {D:/vw/d0_33_Thresholding_rtl_2/thresholding.sv}
read_verilog -sv {D:/vw/d0_33_Thresholding_rtl_2/thresholding_axi.sv}
read_verilog {D:/vw/d0_33_Thresholding_rtl_2/Thresholding_rtl_2_axi_wrapper.v}
read_verilog {D:/vw/d0_33_Thresholding_rtl_2/axilite_if.v}
synth_design -top Thresholding_rtl_2_axi_wrapper -part xc7z020clg400-1 -mode out_of_context
report_utilization -file vivado_util.rpt
create_clock -period 8.000 -name ap_clk [get_ports ap_clk]
report_power -file vivado_power.rpt
