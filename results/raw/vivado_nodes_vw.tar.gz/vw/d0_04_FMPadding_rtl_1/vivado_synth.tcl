read_verilog -sv {D:/vw/d0_04_FMPadding_rtl_1/axi2we.sv}
read_verilog -sv {D:/vw/d0_04_FMPadding_rtl_1/fmpadding.sv}
read_verilog -sv {D:/vw/d0_04_FMPadding_rtl_1/fmpadding_axi.sv}
read_verilog {D:/vw/d0_04_FMPadding_rtl_1/FMPadding_rtl_1.v}
synth_design -top FMPadding_rtl_1 -part xc7z020clg400-1 -mode out_of_context
report_utilization -file vivado_util.rpt
create_clock -period 8.000 -name ap_clk [get_ports ap_clk]
report_power -file vivado_power.rpt
