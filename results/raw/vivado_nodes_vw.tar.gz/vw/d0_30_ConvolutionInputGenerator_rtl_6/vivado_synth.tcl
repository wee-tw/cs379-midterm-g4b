read_verilog -sv {D:/vw/d0_30_ConvolutionInputGenerator_rtl_6/swg_pkg.sv}
read_verilog -sv {D:/vw/d0_30_ConvolutionInputGenerator_rtl_6/ConvolutionInputGenerator_rtl_6_impl.sv}
read_verilog -sv {D:/vw/d0_30_ConvolutionInputGenerator_rtl_6/swg_common.sv}
read_verilog {D:/vw/d0_30_ConvolutionInputGenerator_rtl_6/ConvolutionInputGenerator_rtl_6_wrapper.v}
synth_design -top ConvolutionInputGenerator_rtl_6 -part xc7z020clg400-1 -mode out_of_context
report_utilization -file vivado_util.rpt
create_clock -period 8.000 -name ap_clk [get_ports ap_clk]
report_power -file vivado_power.rpt
