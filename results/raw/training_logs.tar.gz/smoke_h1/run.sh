#!/bin/bash
# Smoke test of the handover-1 commands on CPU with a 1,024-image subset.
S="C:/Users/wee/AppData/Local/Temp/claude/D--115-1-embedded-sys-midterm-report/0ab647fd-9b9f-46c9-8993-886b1139c5f2/scratchpad"
PY="$S/venv_finn010/Scripts/python.exe"
CODE="D:/115-1/embedded sys midterm report/code"
W="$S/smoke_h1"
export CUDA_VISIBLE_DEVICES=-1 OMP_NUM_THREADS=8 PYTHONWARNINGS=ignore
"$PY" -c "
import numpy as np
d = np.load(r'$S/cifar_hf/cifar10.npz')
np.savez(r'$W/small.npz', x_train=d['x_train'][:1024], y_train=d['y_train'][:1024],
         x_test=d['x_test'][:512], y_test=d['y_test'][:512])
print('small npz ok')"
cd "$CODE"
T="--model brevitas --recipe lowbit --epochs 1 --data $W/small.npz"
"$PY" train_cifar.py $T --bits 8 8 8 8 8 8 8 8 --lr 0.1 --save "$W/w8a8.pt" --log "$W/w8a8.json" 2>&1 | tail -1
"$PY" train_cifar.py $T --bits 4 4 4 4 4 4 8 8 --lr 0.02 --init "$W/w8a8.pt" --save "$W/w4a4.pt" --log "$W/w4a4.json" 2>&1 | tail -1
"$PY" train_cifar.py $T --bits 2 2 2 2 2 2 8 8 --lr 0.02 --init "$W/w4a4.pt" --teacher "$S/runs/float_rn8.pt" --save "$W/w2a2.pt" --log "$W/w2a2.json" 2>&1 | tail -1
"$PY" train_cifar.py $T --bits 4 4 2 4 4 4 8 8 --lr 0.02 --init "$W/w4a4.pt" --log "$W/sens_g2w2.json" 2>&1 | tail -1
"$PY" -c "import torch; print('device used:', 'cuda' if torch.cuda.is_available() else 'cpu')"
"$PY" verify_resnet8.py count --bits 8 8 8 8 8 8 8 8 2>&1 | tail -3
