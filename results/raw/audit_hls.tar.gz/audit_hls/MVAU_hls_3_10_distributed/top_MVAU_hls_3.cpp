
#define AP_INT_MAX_W 32

#include "bnn-library.h"

// includes for network parameters
#include "weights.hpp"
#include "activations.hpp"
#include "mvau.hpp"
#include "thresh.h"

// defines for network parameters
#define MW1 16
 #define MH1 32

            #define SIMD1 8
 #define PE1 1
 #define WMEM1 64

            #define TMEM1 32
 #define numReps 256
#define WP1 4


void MVAU_hls_3(
                    hls::stream<ap_uint<32>> &in0_V,
                    hls::stream<ap_uint<32>> &weights_V,
                    hls::stream<ap_uint<4>> &out_V
                    )
{
#pragma HLS INTERFACE axis port=in0_V
#pragma HLS INTERFACE axis port=out_V
#pragma HLS INTERFACE ap_ctrl_none port=return
#pragma HLS INTERFACE axis port=weights_V
#pragma HLS ARRAY_PARTITION variable=threshs.m_thresholds complete dim=1
#pragma HLS ARRAY_PARTITION variable=threshs.m_thresholds complete dim=3
#pragma HLS RESOURCE variable=threshs.m_thresholds core=ROM_2P_LUTRAM
Matrix_Vector_Activate_Stream_Batch<MW1, MH1, SIMD1, PE1, Slice<ap_uint<4>>, Slice<ap_uint<4>>, Identity, ap_int<4> >
                (in0_V, out_V, weights_V, threshs, numReps, ap_resource_lut());
}
