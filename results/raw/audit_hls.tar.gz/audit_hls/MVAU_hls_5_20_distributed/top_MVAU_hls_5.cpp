
#define AP_INT_MAX_W 192

#include "bnn-library.h"

// includes for network parameters
#include "weights.hpp"
#include "activations.hpp"
#include "mvau.hpp"
#include "thresh.h"

// defines for network parameters
#define MW1 288
 #define MH1 32

            #define SIMD1 96
 #define PE1 1
 #define WMEM1 96

            #define TMEM1 32
 #define numReps 256
#define WP1 2


void MVAU_hls_5(
                    hls::stream<ap_uint<192>> &in0_V,
                    hls::stream<ap_uint<192>> &weights_V,
                    hls::stream<ap_uint<2>> &out_V
                    )
{
#pragma HLS INTERFACE axis port=in0_V
#pragma HLS INTERFACE axis port=out_V
#pragma HLS INTERFACE ap_ctrl_none port=return
#pragma HLS INTERFACE axis port=weights_V
#pragma HLS ARRAY_PARTITION variable=threshs.m_thresholds complete dim=1
#pragma HLS ARRAY_PARTITION variable=threshs.m_thresholds complete dim=3
#pragma HLS RESOURCE variable=threshs.m_thresholds core=ROM_2P_LUTRAM
Matrix_Vector_Activate_Stream_Batch<MW1, MH1, SIMD1, PE1, Slice<ap_uint<2>>, Slice<ap_uint<2>>, Identity, ap_int<2> >
                (in0_V, out_V, weights_V, threshs, numReps, ap_resource_lut());
}
