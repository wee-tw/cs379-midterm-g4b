//Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2022.2 (win64) Build 3671981 Fri Oct 14 05:00:03 MDT 2022
//Date        : Fri Oct 30 11:56:07 2026
//Host        : <host> running 64-bit major release  (build 9200)
//Command     : generate_target bd_0_wrapper.bd
//Design      : bd_0_wrapper
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module bd_0_wrapper
   (ap_clk,
    ap_rst_n,
    in0_V_tdata,
    in0_V_tready,
    in0_V_tvalid,
    out_V_tdata,
    out_V_tready,
    out_V_tvalid,
    weights_V_tdata,
    weights_V_tready,
    weights_V_tvalid);
  input ap_clk;
  input ap_rst_n;
  input [31:0]in0_V_tdata;
  output in0_V_tready;
  input in0_V_tvalid;
  output [7:0]out_V_tdata;
  input out_V_tready;
  output out_V_tvalid;
  input [31:0]weights_V_tdata;
  output weights_V_tready;
  input weights_V_tvalid;

  wire ap_clk;
  wire ap_rst_n;
  wire [31:0]in0_V_tdata;
  wire in0_V_tready;
  wire in0_V_tvalid;
  wire [7:0]out_V_tdata;
  wire out_V_tready;
  wire out_V_tvalid;
  wire [31:0]weights_V_tdata;
  wire weights_V_tready;
  wire weights_V_tvalid;

  bd_0 bd_0_i
       (.ap_clk(ap_clk),
        .ap_rst_n(ap_rst_n),
        .in0_V_tdata(in0_V_tdata),
        .in0_V_tready(in0_V_tready),
        .in0_V_tvalid(in0_V_tvalid),
        .out_V_tdata(out_V_tdata),
        .out_V_tready(out_V_tready),
        .out_V_tvalid(out_V_tvalid),
        .weights_V_tdata(weights_V_tdata),
        .weights_V_tready(weights_V_tready),
        .weights_V_tvalid(weights_V_tvalid));
endmodule
