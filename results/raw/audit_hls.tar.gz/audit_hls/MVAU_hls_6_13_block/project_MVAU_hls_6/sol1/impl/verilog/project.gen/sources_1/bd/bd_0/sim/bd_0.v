//Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2022.2 (win64) Build 3671981 Fri Oct 14 05:00:03 MDT 2022
//Date        : Fri Oct 30 11:56:07 2026
//Host        : <host> running 64-bit major release  (build 9200)
//Command     : generate_target bd_0.bd
//Design      : bd_0
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CORE_GENERATION_INFO = "bd_0,IP_Integrator,{x_ipVendor=xilinx.com,x_ipLibrary=BlockDiagram,x_ipName=bd_0,x_ipVersion=1.00.a,x_ipLanguage=VERILOG,numBlks=1,numReposBlks=1,numNonXlnxBlks=0,numHierBlks=0,maxHierDepth=0,numSysgenBlks=0,numHlsBlks=1,numHdlrefBlks=0,numPkgbdBlks=0,bdsource=USER,synth_mode=OOC_per_IP}" *) (* HW_HANDOFF = "bd_0.hwdef" *) 
module bd_0
   (ap_clk,
    ap_rst_n,
    in0_V_tdata,
    in0_V_tready,
    in0_V_tvalid,
    out_V_tdata,
    out_V_tready,
    out_V_tvalid,
    weights_V_tdata,
    weights_V_tready,
    weights_V_tvalid);
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 CLK.AP_CLK CLK" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME CLK.AP_CLK, ASSOCIATED_BUSIF in0_V:out_V:weights_V, ASSOCIATED_RESET ap_rst_n, CLK_DOMAIN bd_0_ap_clk_0, FREQ_HZ 100000000.0, FREQ_TOLERANCE_HZ 0, INSERT_VIP 0, PHASE 0.0" *) input ap_clk;
  (* X_INTERFACE_INFO = "xilinx.com:signal:reset:1.0 RST.AP_RST_N RST" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME RST.AP_RST_N, INSERT_VIP 0, POLARITY ACTIVE_LOW" *) input ap_rst_n;
  (* X_INTERFACE_INFO = "xilinx.com:interface:axis:1.0 in0_V " *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME in0_V, CLK_DOMAIN bd_0_ap_clk_0, FREQ_HZ 100000000.0, HAS_TKEEP 0, HAS_TLAST 0, HAS_TREADY 1, HAS_TSTRB 0, INSERT_VIP 0, LAYERED_METADATA undef, PHASE 0.0, TDATA_NUM_BYTES 4, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0" *) input [31:0]in0_V_tdata;
  (* X_INTERFACE_INFO = "xilinx.com:interface:axis:1.0 in0_V " *) output in0_V_tready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:axis:1.0 in0_V " *) input in0_V_tvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:axis:1.0 out_V " *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME out_V, CLK_DOMAIN bd_0_ap_clk_0, FREQ_HZ 100000000.0, HAS_TKEEP 0, HAS_TLAST 0, HAS_TREADY 1, HAS_TSTRB 0, INSERT_VIP 0, LAYERED_METADATA undef, PHASE 0.0, TDATA_NUM_BYTES 1, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0" *) output [7:0]out_V_tdata;
  (* X_INTERFACE_INFO = "xilinx.com:interface:axis:1.0 out_V " *) input out_V_tready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:axis:1.0 out_V " *) output out_V_tvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:axis:1.0 weights_V " *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME weights_V, CLK_DOMAIN bd_0_ap_clk_0, FREQ_HZ 100000000.0, HAS_TKEEP 0, HAS_TLAST 0, HAS_TREADY 1, HAS_TSTRB 0, INSERT_VIP 0, LAYERED_METADATA undef, PHASE 0.0, TDATA_NUM_BYTES 4, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0" *) input [31:0]weights_V_tdata;
  (* X_INTERFACE_INFO = "xilinx.com:interface:axis:1.0 weights_V " *) output weights_V_tready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:axis:1.0 weights_V " *) input weights_V_tvalid;

  wire ap_clk_0_1;
  wire ap_rst_n_0_1;
  wire [7:0]hls_inst_out_V_TDATA;
  wire hls_inst_out_V_TREADY;
  wire hls_inst_out_V_TVALID;
  wire [31:0]in0_V_0_1_TDATA;
  wire in0_V_0_1_TREADY;
  wire in0_V_0_1_TVALID;
  wire [31:0]weights_V_0_1_TDATA;
  wire weights_V_0_1_TREADY;
  wire weights_V_0_1_TVALID;

  assign ap_clk_0_1 = ap_clk;
  assign ap_rst_n_0_1 = ap_rst_n;
  assign hls_inst_out_V_TREADY = out_V_tready;
  assign in0_V_0_1_TDATA = in0_V_tdata[31:0];
  assign in0_V_0_1_TVALID = in0_V_tvalid;
  assign in0_V_tready = in0_V_0_1_TREADY;
  assign out_V_tdata[7:0] = hls_inst_out_V_TDATA;
  assign out_V_tvalid = hls_inst_out_V_TVALID;
  assign weights_V_0_1_TDATA = weights_V_tdata[31:0];
  assign weights_V_0_1_TVALID = weights_V_tvalid;
  assign weights_V_tready = weights_V_0_1_TREADY;
  bd_0_hls_inst_0 hls_inst
       (.ap_clk(ap_clk_0_1),
        .ap_rst_n(ap_rst_n_0_1),
        .in0_V_TDATA(in0_V_0_1_TDATA),
        .in0_V_TREADY(in0_V_0_1_TREADY),
        .in0_V_TVALID(in0_V_0_1_TVALID),
        .out_V_TDATA(hls_inst_out_V_TDATA),
        .out_V_TREADY(hls_inst_out_V_TREADY),
        .out_V_TVALID(hls_inst_out_V_TVALID),
        .weights_V_TDATA(weights_V_0_1_TDATA),
        .weights_V_TREADY(weights_V_0_1_TREADY),
        .weights_V_TVALID(weights_V_0_1_TVALID));
endmodule
