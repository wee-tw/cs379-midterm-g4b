read_verilog -sv {D:/va/ConvolutionInputGenerator_rtl_031/ConvolutionInputGenerator_rtl_0_impl.sv}
read_verilog -sv {D:/va/ConvolutionInputGenerator_rtl_031/swg_common.sv}
read_verilog -sv {D:/va/ConvolutionInputGenerator_rtl_031/swg_pkg.sv}
read_verilog {D:/va/ConvolutionInputGenerator_rtl_031/ConvolutionInputGenerator_rtl_0_wrapper.v}
synth_design -top ConvolutionInputGenerator_rtl_0 -part xc7z020clg400-1 -mode out_of_context
report_utilization -file vivado_util.rpt
