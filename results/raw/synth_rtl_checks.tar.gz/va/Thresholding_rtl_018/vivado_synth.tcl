read_verilog -sv {D:/va/Thresholding_rtl_018/thresholding.sv}
read_verilog -sv {D:/va/Thresholding_rtl_018/thresholding_axi.sv}
read_verilog {D:/va/Thresholding_rtl_018/Thresholding_rtl_7_axi_wrapper.v}
read_verilog {D:/va/Thresholding_rtl_018/axilite_if.v}
synth_design -top Thresholding_rtl_7_axi_wrapper -part xc7z020clg400-1 -mode out_of_context
report_utilization -file vivado_util.rpt
