read_verilog -sv {D:/va/ConvolutionInputGenerator_rtl_095/ConvolutionInputGenerator_rtl_4_impl.sv}
read_verilog -sv {D:/va/ConvolutionInputGenerator_rtl_095/swg_common.sv}
read_verilog -sv {D:/va/ConvolutionInputGenerator_rtl_095/swg_pkg.sv}
read_verilog {D:/va/ConvolutionInputGenerator_rtl_095/ConvolutionInputGenerator_rtl_4_wrapper.v}
synth_design -top ConvolutionInputGenerator_rtl_4 -part xc7z020clg400-1 -mode out_of_context
report_utilization -file vivado_util.rpt
