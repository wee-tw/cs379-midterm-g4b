read_verilog -sv {D:/va/FMPadding_rtl_075/axi2we.sv}
read_verilog -sv {D:/va/FMPadding_rtl_075/fmpadding.sv}
read_verilog -sv {D:/va/FMPadding_rtl_075/fmpadding_axi.sv}
read_verilog {D:/va/FMPadding_rtl_075/FMPadding_rtl_1.v}
synth_design -top FMPadding_rtl_1 -part xc7z020clg400-1 -mode out_of_context
report_utilization -file vivado_util.rpt
