read_verilog -sv {D:/va/FMPadding_rtl_014/axi2we.sv}
read_verilog -sv {D:/va/FMPadding_rtl_014/fmpadding.sv}
read_verilog -sv {D:/va/FMPadding_rtl_014/fmpadding_axi.sv}
read_verilog {D:/va/FMPadding_rtl_014/FMPadding_rtl_4.v}
synth_design -top FMPadding_rtl_4 -part xc7z020clg400-1 -mode out_of_context
report_utilization -file vivado_util.rpt
