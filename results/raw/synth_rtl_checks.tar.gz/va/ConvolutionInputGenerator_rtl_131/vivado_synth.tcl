read_verilog -sv {D:/va/ConvolutionInputGenerator_rtl_131/ConvolutionInputGenerator_rtl_7_impl.sv}
read_verilog -sv {D:/va/ConvolutionInputGenerator_rtl_131/swg_common.sv}
read_verilog -sv {D:/va/ConvolutionInputGenerator_rtl_131/swg_pkg.sv}
read_verilog {D:/va/ConvolutionInputGenerator_rtl_131/ConvolutionInputGenerator_rtl_7_wrapper.v}
synth_design -top ConvolutionInputGenerator_rtl_7 -part xc7z020clg400-1 -mode out_of_context
report_utilization -file vivado_util.rpt
