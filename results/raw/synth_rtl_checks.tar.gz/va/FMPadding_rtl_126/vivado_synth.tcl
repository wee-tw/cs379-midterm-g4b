read_verilog -sv {D:/va/FMPadding_rtl_126/axi2we.sv}
read_verilog -sv {D:/va/FMPadding_rtl_126/fmpadding.sv}
read_verilog -sv {D:/va/FMPadding_rtl_126/fmpadding_axi.sv}
read_verilog {D:/va/FMPadding_rtl_126/FMPadding_rtl_6.v}
synth_design -top FMPadding_rtl_6 -part xc7z020clg400-1 -mode out_of_context
report_utilization -file vivado_util.rpt
