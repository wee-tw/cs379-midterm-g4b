read_verilog -sv {D:/va/ConvolutionInputGenerator_rtl_133/ConvolutionInputGenerator_rtl_1_impl.sv}
read_verilog -sv {D:/va/ConvolutionInputGenerator_rtl_133/swg_common.sv}
read_verilog -sv {D:/va/ConvolutionInputGenerator_rtl_133/swg_pkg.sv}
read_verilog {D:/va/ConvolutionInputGenerator_rtl_133/ConvolutionInputGenerator_rtl_1_wrapper.v}
synth_design -top ConvolutionInputGenerator_rtl_1 -part xc7z020clg400-1 -mode out_of_context
report_utilization -file vivado_util.rpt
