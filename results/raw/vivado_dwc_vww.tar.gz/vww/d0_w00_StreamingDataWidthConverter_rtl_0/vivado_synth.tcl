read_verilog -sv {D:/vww/d0_w00_StreamingDataWidthConverter_rtl_0/dwc.sv}
read_verilog -sv {D:/vww/d0_w00_StreamingDataWidthConverter_rtl_0/dwc_axi.sv}
read_verilog {D:/vww/d0_w00_StreamingDataWidthConverter_rtl_0/StreamingDataWidthConverter_rtl_0.v}
read_xdc -mode out_of_context clock.xdc
synth_design -top StreamingDataWidthConverter_rtl_0 -part xc7z020clg400-1 -mode out_of_context
report_utilization -file vivado_util.rpt
report_timing_summary -file vivado_timing.rpt
report_power -file vivado_power.rpt
