read_verilog -sv {D:/vww/d1_w18_StreamingDataWidthConverter_rtl_18/dwc.sv}
read_verilog -sv {D:/vww/d1_w18_StreamingDataWidthConverter_rtl_18/dwc_axi.sv}
read_verilog {D:/vww/d1_w18_StreamingDataWidthConverter_rtl_18/StreamingDataWidthConverter_rtl_18.v}
read_xdc -mode out_of_context clock.xdc
synth_design -top StreamingDataWidthConverter_rtl_18 -part xc7z020clg400-1 -mode out_of_context
report_utilization -file vivado_util.rpt
report_timing_summary -file vivado_timing.rpt
report_power -file vivado_power.rpt
