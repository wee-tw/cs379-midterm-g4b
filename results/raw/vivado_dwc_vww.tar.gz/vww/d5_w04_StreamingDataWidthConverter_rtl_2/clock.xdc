create_clock -period 10.000 -name ap_clk [get_ports ap_clk]
