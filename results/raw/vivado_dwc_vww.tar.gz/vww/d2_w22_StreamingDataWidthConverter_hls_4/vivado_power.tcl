open_checkpoint {D:/vww/d2_w22_StreamingDataWidthConverter_hls_4/project_StreamingDataWidthConverter_hls_4/sol1/impl/verilog/project.runs/bd_0_hls_inst_0_synth_1/bd_0_hls_inst_0.dcp}
create_clock -period 8.000 -name ap_clk [get_ports ap_clk]
report_power -file vivado_power.rpt
