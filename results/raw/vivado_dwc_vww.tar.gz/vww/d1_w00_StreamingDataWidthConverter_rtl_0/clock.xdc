create_clock -period 9.000 -name ap_clk [get_ports ap_clk]
