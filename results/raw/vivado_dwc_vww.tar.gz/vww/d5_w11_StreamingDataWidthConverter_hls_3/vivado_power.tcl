open_checkpoint {D:/vww/d5_w11_StreamingDataWidthConverter_hls_3/project_StreamingDataWidthConverter_hls_3/sol1/impl/verilog/project.runs/bd_0_hls_inst_0_synth_1/bd_0_hls_inst_0.dcp}
create_clock -period 10.000 -name ap_clk [get_ports ap_clk]
report_power -file vivado_power.rpt
