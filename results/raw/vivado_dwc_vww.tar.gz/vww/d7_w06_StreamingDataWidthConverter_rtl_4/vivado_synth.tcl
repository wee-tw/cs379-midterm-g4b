read_verilog -sv {D:/vww/d7_w06_StreamingDataWidthConverter_rtl_4/dwc.sv}
read_verilog -sv {D:/vww/d7_w06_StreamingDataWidthConverter_rtl_4/dwc_axi.sv}
read_verilog {D:/vww/d7_w06_StreamingDataWidthConverter_rtl_4/StreamingDataWidthConverter_rtl_4.v}
read_xdc -mode out_of_context clock.xdc
synth_design -top StreamingDataWidthConverter_rtl_4 -part xc7z020clg400-1 -mode out_of_context
report_utilization -file vivado_util.rpt
report_timing_summary -file vivado_timing.rpt
report_power -file vivado_power.rpt
