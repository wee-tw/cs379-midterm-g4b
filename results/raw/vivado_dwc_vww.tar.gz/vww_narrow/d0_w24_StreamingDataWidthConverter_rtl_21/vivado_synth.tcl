read_verilog -sv {D:/vww_narrow/d0_w24_StreamingDataWidthConverter_rtl_21/dwc.sv}
read_verilog -sv {D:/vww_narrow/d0_w24_StreamingDataWidthConverter_rtl_21/dwc_axi.sv}
read_verilog {D:/vww_narrow/d0_w24_StreamingDataWidthConverter_rtl_21/StreamingDataWidthConverter_rtl_21.v}
read_xdc -mode out_of_context clock.xdc
synth_design -top StreamingDataWidthConverter_rtl_21 -part xc7z020clg400-1 -mode out_of_context
report_utilization -file vivado_util.rpt
report_timing_summary -file vivado_timing.rpt
report_power -file vivado_power.rpt
