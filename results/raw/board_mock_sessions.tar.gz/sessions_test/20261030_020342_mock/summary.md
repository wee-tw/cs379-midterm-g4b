| model | idle a (W) | idle slope (mW/MHz) | halted idle (W) | slowest-clock idle (W) | cont slope (mW/MHz) |
|---|---|---|---|---|---|
| cnv-w1a1 | 1.299 | 3.64 | 1.3001 | 1.2994 | 4.61 |
| cnv-w1a2 | 1.2999 | 3.70 | 1.3 | 1.3006 | 4.75 |
| cnv-w2a2 | 1.3 | 3.55 | 1.2998 | 1.3015 | 4.38 |

- cnv-w1a1 R=50: rate@100MHz 33.3536 mJ (late 0.72), rate@200MHz 40.779 mJ (late 0.72), rate@50MHz 29.6916 mJ (late 0.72), rate_halt 26.3005 mJ (late 0.71), rate_slow 26.2726 mJ (late 0.71)
- cnv-w1a2 R=50: rate@100MHz 33.6111 mJ (late 0.71), rate@200MHz 40.917 mJ (late 0.72), rate@50MHz 29.7797 mJ (late 0.72), rate_halt 26.1977 mJ (late 0.71), rate_slow 26.1494 mJ (late 0.73)
- cnv-w2a2 R=50: rate@100MHz 33.2311 mJ (late 0.7), rate@200MHz 40.4085 mJ (late 0.71), rate@50MHz 29.5949 mJ (late 0.72), rate_halt 26.1678 mJ (late 0.72), rate_slow 26.1481 mJ (late 0.72)

global fit: {"models": ["cnv-w1a1", "cnv-w1a2", "cnv-w2a2"], "U": [0.64, 0.7, 0.55], "k_f": 0.003, "k_fU": 0.001026, "k_act_per_U": 0.001509, "P0_halt_mean": 1.3}