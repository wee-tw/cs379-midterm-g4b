| model | idle a (W) | idle slope (mW/MHz) | halted idle (W) | slowest-clock idle (W) | cont slope (mW/MHz) |
|---|---|---|---|---|---|
| cnv-w1a1 | 1.3008 | 3.63 | 1.2995 | 1.3009 | 4.60 |

- cnv-w1a1 R=100: jit@3.44MHz 10.3644 mJ (late 0.0), rate@100MHz 26.3145 mJ (late 1.0), rate@200MHz 31.908 mJ (late 1.0), rate_halt 20.7737 mJ (late 1.0), rate_halt_k2 13.2064 mJ (late 0.373), rate_halt_k4 13.198 mJ (late 0.0), rate_halt_k8 13.1093 mJ (late 0.0), rate_poll@200MHz 32.0051 mJ (late 1.0), rate_slow 20.7984 mJ (late 1.0)