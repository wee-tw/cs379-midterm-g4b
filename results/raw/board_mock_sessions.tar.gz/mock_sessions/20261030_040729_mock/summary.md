| model | idle a (W) | idle slope (mW/MHz) | halted idle (W) | slowest-clock idle (W) | cont slope (mW/MHz) |
|---|---|---|---|---|---|
| cnv-w1a1 | 1.5 | 2.00 | 1.4 | 1.8 | 2.00 |

- cnv-w1a1 R=100: rate@100MHz 26.5957 mJ (late 1.0), rate@200MHz 29.8554 mJ (late 1.0), rate_halt 22.0403 mJ (late 1.0), rate_slow 29.7014 mJ (late 1.0)

slope error vs pre-session predictions (U_cal; mW/MHz RMS over models): flat 0.747, z2_anchor 1.867, nominal 2.795, bismo_fit 5.542