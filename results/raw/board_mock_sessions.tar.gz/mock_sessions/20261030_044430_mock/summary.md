| model | idle a (W) | idle slope (mW/MHz) | halted idle (W) | slowest-clock idle (W) | cont slope (mW/MHz) |
|---|---|---|---|---|---|
| cnv-w1a1 | 1.5 | 0.00 | 1.4 | 1.5 | 0.00 |

- cnv-w1a1 R=100: jit@3.44MHz 7.3253 mJ (late 0.0), rate@100MHz 24.323 mJ (late 1.0), rate@200MHz 23.6128 mJ (late 1.0), rate_halt 22.0716 mJ (late 1.0), rate_poll@200MHz 23.5738 mJ (late 1.0), rate_slow 23.4595 mJ (late 1.0)

slope error vs pre-session predictions (U_cal; mW/MHz RMS over models): flat 1.0, z2_anchor 3.508, nominal 3.762, bismo_fit 6.063