# Timing-only board session (finn-examples bitstreams on PYNQ-Z2; measured)

| model | top-1 (1000 img) | throttle (probe / verified) | II measured (cycles) | FINN II | meas/est | L measured (cycles) | FINN L | meas/est | r = L/II meas / est | per-image overhead cont / single (us) |
|---|---|---|---|---|---|---|---|---|---|---|
| cnv-w1a1 | 9.9 | True / True | 16254.4 | 32768 | 0.496 | 3050.2 | 249362 | 0.012 | 0.19 / 7.61 | 10.29 / 15507.26 |
| cnv-w1a2 | 9.9 | True / True | 16197.9 | 115200 | 0.141 | -3892.9 | 720242 | -0.005 | -0.24 / 6.25 | 9.3 / 15628.33 |
| cnv-w2a2 | 9.9 | True / True | 16295.0 | 115200 | 0.141 | -1518.2 | 720242 | -0.002 | -0.09 / 6.25 | 10.49 / 15558.53 |
| kwsmlp-w3a3 | None | True / True | 2093.9 | 392 | 5.342 | 690.1 | 1300 | 0.531 | 0.33 / 3.32 | 7.99 / 15540.6 |
| tfc-w1a1 | None | True / True | 2029.4 | 64 | 31.709 | -5267.5 | 226 | -23.308 | -2.6 / 3.53 | 9.94 / 15680.27 |

## Fixed-rate policies (achieved rate, share of late frames)

- cnv-w1a1 jit @ 100 FPS, 3.43643 MHz: 157.26 FPS, late 0.0, halts 0, failed halts 0
- cnv-w1a1 jit @ 1000 FPS, 34.4828 MHz: 1611.66 FPS, late 0.0, halts 0, failed halts 0
- cnv-w1a1 jit @ 300 FPS, 10.4167 MHz: 483.22 FPS, late 0.0, halts 0, failed halts 0
- cnv-w1a1 jit @ 300 FPS, 22.7273 MHz: 853.57 FPS, late 0.0, halts 0, failed halts 0
- cnv-w1a1 jit @ 300 FPS, 35.7143 MHz: 818.61 FPS, late 0.0, halts 0, failed halts 0
- cnv-w1a1 rate_halt @ 100 FPS, 200 MHz: 63.79 FPS, late 1.0, halts 21, failed halts 0
- cnv-w1a1 rate_halt @ 1000 FPS, 200 MHz: 65.19 FPS, late 1.0, halts 21, failed halts 0
- cnv-w1a1 rate_halt @ 300 FPS, 200 MHz: 64.36 FPS, late 1.0, halts 21, failed halts 0
- cnv-w1a1 rate_halt_k2 @ 1000 FPS, 200 MHz: 129.27 FPS, late 0.5, halts 21, failed halts 0
- cnv-w1a1 rate_halt_k2 @ 300 FPS, 200 MHz: 128.95 FPS, late 0.5, halts 21, failed halts 0
- cnv-w1a1 rate_halt_k4 @ 1000 FPS, 200 MHz: 258.99 FPS, late 0.25, halts 21, failed halts 0
- cnv-w1a1 rate_halt_k8 @ 1000 FPS, 200 MHz: 514.17 FPS, late 0.125, halts 21, failed halts 0
- cnv-w1a1 rate_slow @ 100 FPS, 200 MHz: 65.28 FPS, late 1.0, halts 0, failed halts 0
- cnv-w1a1 rate_slow @ 1000 FPS, 200 MHz: 64.26 FPS, late 1.0, halts 0, failed halts 0
- cnv-w1a2 jit @ 100 FPS, 12.0482 MHz: 285.23 FPS, late 0.0, halts 0, failed halts 0
- cnv-w1a2 jit @ 1000 FPS, 125 MHz: 3553.52 FPS, late 0.0, halts 0, failed halts 0
- cnv-w1a2 rate_halt @ 100 FPS, 200 MHz: 64.28 FPS, late 1.0, halts 21, failed halts 0
- cnv-w1a2 rate_halt @ 1000 FPS, 200 MHz: 65.32 FPS, late 1.0, halts 21, failed halts 0
- cnv-w1a2 rate_halt_k2 @ 1000 FPS, 200 MHz: 130.0 FPS, late 0.5, halts 21, failed halts 0
- cnv-w1a2 rate_halt_k4 @ 1000 FPS, 200 MHz: 261.04 FPS, late 0.25, halts 21, failed halts 0
- cnv-w1a2 rate_halt_k8 @ 1000 FPS, 200 MHz: 516.16 FPS, late 0.125, halts 21, failed halts 0
- cnv-w1a2 rate_slow @ 100 FPS, 200 MHz: 65.11 FPS, late 1.0, halts 0, failed halts 0
- cnv-w1a2 rate_slow @ 1000 FPS, 200 MHz: 65.13 FPS, late 1.0, halts 0, failed halts 0
- cnv-w2a2 jit @ 100 FPS, 12.0482 MHz: 277.85 FPS, late 0.0, halts 0, failed halts 0
- cnv-w2a2 jit @ 1000 FPS, 125 MHz: 2832.3 FPS, late 0.0, halts 0, failed halts 0
- cnv-w2a2 rate_halt @ 100 FPS, 200 MHz: 60.67 FPS, late 1.0, halts 20, failed halts 0
- cnv-w2a2 rate_halt @ 1000 FPS, 200 MHz: 64.94 FPS, late 1.0, halts 21, failed halts 0
- cnv-w2a2 rate_halt_k2 @ 1000 FPS, 200 MHz: 128.85 FPS, late 0.5, halts 21, failed halts 0
- cnv-w2a2 rate_halt_k4 @ 1000 FPS, 200 MHz: 255.11 FPS, late 0.25, halts 21, failed halts 0
- cnv-w2a2 rate_halt_k8 @ 1000 FPS, 200 MHz: 518.85 FPS, late 0.125, halts 21, failed halts 0
- cnv-w2a2 rate_slow @ 100 FPS, 200 MHz: 64.04 FPS, late 1.0, halts 0, failed halts 0
- cnv-w2a2 rate_slow @ 1000 FPS, 200 MHz: 64.22 FPS, late 1.0, halts 0, failed halts 0
- kwsmlp-w3a3 jit @ 100 FPS, 0.251953 MHz: 112.39 FPS, late 0.0, halts 0, failed halts 0
- kwsmlp-w3a3 jit @ 1000 FPS, 0.411523 MHz: 196.32 FPS, late 0.0, halts 0, failed halts 0
- kwsmlp-w3a3 rate_halt @ 100 FPS, 100 MHz: 63.87 FPS, late 1.0, halts 21, failed halts 0
- kwsmlp-w3a3 rate_halt @ 1000 FPS, 100 MHz: 64.62 FPS, late 1.0, halts 21, failed halts 0
- kwsmlp-w3a3 rate_slow @ 100 FPS, 100 MHz: 64.39 FPS, late 1.0, halts 0, failed halts 0
- kwsmlp-w3a3 rate_slow @ 1000 FPS, 100 MHz: 64.9 FPS, late 1.0, halts 0, failed halts 0
- tfc-w1a1 jit @ 100 FPS, 0.251953 MHz: 114.54 FPS, late 0.0, halts 0, failed halts 0
- tfc-w1a1 jit @ 1000 FPS, 0.251953 MHz: 121.8 FPS, late 0.0, halts 0, failed halts 0
- tfc-w1a1 rate_halt @ 100 FPS, 200 MHz: 64.87 FPS, late 1.0, halts 21, failed halts 0
- tfc-w1a1 rate_halt @ 1000 FPS, 200 MHz: 64.39 FPS, late 1.0, halts 21, failed halts 0
- tfc-w1a1 rate_slow @ 100 FPS, 200 MHz: 64.38 FPS, late 1.0, halts 0, failed halts 0
- tfc-w1a1 rate_slow @ 1000 FPS, 200 MHz: 64.65 FPS, late 1.0, halts 0, failed halts 0
