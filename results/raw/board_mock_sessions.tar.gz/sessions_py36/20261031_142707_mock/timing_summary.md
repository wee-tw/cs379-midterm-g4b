# Timing-only board session (finn-examples bitstreams on PYNQ-Z2; measured)

| model | top-1 (1000 img) | throttle (probe / verified) | II measured (cycles) | FINN II | meas/est | L measured (cycles) | FINN L | meas/est | r = L/II meas / est | per-image overhead cont / single (us) |
|---|---|---|---|---|---|---|---|---|---|---|
| cnv-w1a1 | 9.9 | True / True | 16254.8 | 32768 | 0.496 | -17057.9 | 249362 | -0.068 | -1.05 / 7.61 | 12.64 / 16123.19 |
| cnv-w1a2 | 9.9 | True / True | 16196.5 | 115200 | 0.141 | 985.5 | 720242 | 0.001 | 0.06 / 6.25 | 12.01 / 15542.81 |
| cnv-w2a2 | 9.9 | True / True | 16484.2 | 115200 | 0.143 | 3802.0 | 720242 | 0.005 | 0.23 / 6.25 | 9.5 / 15615.22 |
| kwsmlp-w3a3 | None | True / True | 2103.2 | 392 | 5.365 | -7422.0 | 1300 | -5.709 | -3.53 / 3.32 | 7.86 / 15796.31 |
| tfc-w1a1 | None | True / True | 2265.3 | 64 | 35.395 | 3262.7 | 226 | 14.437 | 1.44 / 3.53 | 5.18 / 15503.06 |

## Fixed-rate policies (achieved rate, share of late frames)

- cnv-w1a1 jit @ 100 FPS, 3.43643 MHz: 160.66 FPS, late 0.0, halts 0, failed halts 0
- cnv-w1a1 jit @ 1000 FPS, 34.4828 MHz: 1603.22 FPS, late 0.0, halts 0, failed halts 0
- cnv-w1a1 jit @ 300 FPS, 10.4167 MHz: 483.32 FPS, late 0.0, halts 0, failed halts 0
- cnv-w1a1 jit @ 300 FPS, 22.7273 MHz: 814.07 FPS, late 0.0, halts 0, failed halts 0
- cnv-w1a1 jit @ 300 FPS, 35.7143 MHz: 1057.2 FPS, late 0.0, halts 0, failed halts 0
- cnv-w1a1 rate_halt @ 100 FPS, 200 MHz: 63.57 FPS, late 1.0, halts 21, failed halts 0
- cnv-w1a1 rate_halt @ 1000 FPS, 200 MHz: 65.11 FPS, late 1.0, halts 21, failed halts 0
- cnv-w1a1 rate_halt @ 300 FPS, 200 MHz: 64.46 FPS, late 1.0, halts 21, failed halts 0
- cnv-w1a1 rate_halt_k2 @ 1000 FPS, 200 MHz: 131.16 FPS, late 0.5, halts 21, failed halts 0
- cnv-w1a1 rate_halt_k2 @ 300 FPS, 200 MHz: 128.42 FPS, late 0.5, halts 21, failed halts 0
- cnv-w1a1 rate_halt_k4 @ 1000 FPS, 200 MHz: 259.26 FPS, late 0.25, halts 21, failed halts 0
- cnv-w1a1 rate_halt_k8 @ 1000 FPS, 200 MHz: 516.67 FPS, late 0.125, halts 21, failed halts 0
- cnv-w1a1 rate_slow @ 100 FPS, 200 MHz: 64.27 FPS, late 1.0, halts 0, failed halts 0
- cnv-w1a1 rate_slow @ 1000 FPS, 200 MHz: 62.88 FPS, late 1.0, halts 0, failed halts 0
- cnv-w1a2 jit @ 100 FPS, 12.0482 MHz: 284.01 FPS, late 0.0, halts 0, failed halts 0
- cnv-w1a2 jit @ 1000 FPS, 125 MHz: 2851.0 FPS, late 0.0, halts 0, failed halts 0
- cnv-w1a2 rate_halt @ 100 FPS, 200 MHz: 61.11 FPS, late 1.0, halts 20, failed halts 0
- cnv-w1a2 rate_halt @ 1000 FPS, 200 MHz: 61.28 FPS, late 1.0, halts 20, failed halts 0
- cnv-w1a2 rate_halt_k2 @ 1000 FPS, 200 MHz: 123.94 FPS, late 0.5, halts 20, failed halts 0
- cnv-w1a2 rate_halt_k4 @ 1000 FPS, 200 MHz: 259.0 FPS, late 0.25, halts 21, failed halts 0
- cnv-w1a2 rate_halt_k8 @ 1000 FPS, 200 MHz: 517.21 FPS, late 0.125, halts 21, failed halts 0
- cnv-w1a2 rate_slow @ 100 FPS, 200 MHz: 64.52 FPS, late 1.0, halts 0, failed halts 0
- cnv-w1a2 rate_slow @ 1000 FPS, 200 MHz: 64.54 FPS, late 1.0, halts 0, failed halts 0
- cnv-w2a2 jit @ 100 FPS, 12.0482 MHz: 283.02 FPS, late 0.0, halts 0, failed halts 0
- cnv-w2a2 jit @ 1000 FPS, 125 MHz: 2842.41 FPS, late 0.0, halts 0, failed halts 0
- cnv-w2a2 rate_halt @ 100 FPS, 200 MHz: 64.28 FPS, late 1.0, halts 21, failed halts 0
- cnv-w2a2 rate_halt @ 1000 FPS, 200 MHz: 64.88 FPS, late 1.0, halts 21, failed halts 0
- cnv-w2a2 rate_halt_k2 @ 1000 FPS, 200 MHz: 128.4 FPS, late 0.5, halts 21, failed halts 0
- cnv-w2a2 rate_halt_k4 @ 1000 FPS, 200 MHz: 257.74 FPS, late 0.25, halts 21, failed halts 0
- cnv-w2a2 rate_halt_k8 @ 1000 FPS, 200 MHz: 516.76 FPS, late 0.125, halts 21, failed halts 0
- cnv-w2a2 rate_slow @ 100 FPS, 200 MHz: 64.25 FPS, late 1.0, halts 0, failed halts 0
- cnv-w2a2 rate_slow @ 1000 FPS, 200 MHz: 65.06 FPS, late 1.0, halts 0, failed halts 0
- kwsmlp-w3a3 jit @ 100 FPS, 0.251953 MHz: 110.02 FPS, late 0.0, halts 0, failed halts 0
- kwsmlp-w3a3 jit @ 1000 FPS, 0.411523 MHz: 196.19 FPS, late 0.0, halts 0, failed halts 0
- kwsmlp-w3a3 rate_halt @ 100 FPS, 100 MHz: 55.14 FPS, late 1.0, halts 18, failed halts 0
- kwsmlp-w3a3 rate_halt @ 1000 FPS, 100 MHz: 64.75 FPS, late 1.0, halts 21, failed halts 0
- kwsmlp-w3a3 rate_slow @ 100 FPS, 100 MHz: 64.16 FPS, late 1.0, halts 0, failed halts 0
- kwsmlp-w3a3 rate_slow @ 1000 FPS, 100 MHz: 64.17 FPS, late 1.0, halts 0, failed halts 0
- tfc-w1a1 jit @ 100 FPS, 0.251953 MHz: 112.62 FPS, late 0.0, halts 0, failed halts 0
- tfc-w1a1 jit @ 1000 FPS, 0.251953 MHz: 121.96 FPS, late 0.0, halts 0, failed halts 0
- tfc-w1a1 rate_halt @ 100 FPS, 200 MHz: 65.04 FPS, late 1.0, halts 21, failed halts 0
- tfc-w1a1 rate_halt @ 1000 FPS, 200 MHz: 64.74 FPS, late 1.0, halts 21, failed halts 0
- tfc-w1a1 rate_slow @ 100 FPS, 200 MHz: 61.31 FPS, late 1.0, halts 0, failed halts 0
- tfc-w1a1 rate_slow @ 1000 FPS, 200 MHz: 66.91 FPS, late 1.0, halts 0, failed halts 0
