
#define AP_INT_MAX_W 64

#include "bnn-library.h"

// includes for network parameters
#include "streamtools.h"

// defines for network parameters
#define InWidth 64 
#define OutWidth 36 
#define NumInWords 9216 
#define numReps 1
#define LCMWidth 576
#define NumLCMToOut 1024

void StreamingDataWidthConverter_hls_0(hls::stream<ap_uint<64> > &in0_V, hls::stream<ap_uint<36> > &out_V)
{
#pragma HLS INTERFACE axis port=in0_V
#pragma HLS INTERFACE axis port=out_V
#pragma HLS INTERFACE ap_ctrl_none port=return
#pragma HLS DATAFLOW disable_start_propagation
hls::stream<ap_uint<576>> intermediate ("intermediate");
StreamingDataWidthConverter_Batch<InWidth, LCMWidth, NumInWords>(in0_V, intermediate, numReps);
StreamingDataWidthConverter_Batch<LCMWidth, OutWidth, NumLCMToOut>(intermediate, out_V, numReps);
}
