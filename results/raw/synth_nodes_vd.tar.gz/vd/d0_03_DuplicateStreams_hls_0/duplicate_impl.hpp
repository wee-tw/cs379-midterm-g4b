void DuplicateStreamsCustom(
hls::stream<ap_uint<8> > &in0,hls::stream<ap_uint<8> > &out0,hls::stream<ap_uint<8> > &out1
) {
for(unsigned int i = 0; i < 8192; i++) {
#pragma HLS PIPELINE II=1
ap_uint<8> e = in0.read();
out0.write(e);
out1.write(e);
}
}