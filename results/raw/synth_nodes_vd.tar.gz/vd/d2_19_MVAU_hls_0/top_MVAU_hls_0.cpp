
#define AP_INT_MAX_W 64

#include "bnn-library.h"

// includes for network parameters
#include "weights.hpp"
#include "activations.hpp"
#include "mvau.hpp"

// defines for network parameters
#define MW1 16
 #define MH1 32

            #define SIMD1 16
 #define PE1 1
 #define WMEM1 32

            #define TMEM1 0
 #define numReps 256
#define WP1 2


void MVAU_hls_0(
                    hls::stream<ap_uint<64>> &in0_V,
                    hls::stream<ap_uint<32>> &weights_V,
                    hls::stream<ap_uint<8>> &out_V
                    )
{
#pragma HLS INTERFACE axis port=in0_V
#pragma HLS INTERFACE axis port=out_V
#pragma HLS INTERFACE ap_ctrl_none port=return
#pragma HLS INTERFACE axis port=weights_V
Matrix_Vector_Activate_Stream_Batch<MW1, MH1, SIMD1, PE1, Slice<ap_uint<4>>, Slice<ap_int<8>>, Identity, ap_int<2> >
                (in0_V, out_V, weights_V, PassThroughActivation<ap_int<8>>(), numReps, ap_resource_lut());
}
