module wstrm_top(input ap_clk, input ap_rst_n, input m_axis_0_tready,
  output m_axis_0_tvalid, output [63:0] m_axis_0_tdata);
  memstream_axi_wrapper #(.DEPTH(32), .WIDTH(64), .INIT_FILE("memblock.dat"),
    .RAM_STYLE("block")) inst (.ap_clk(ap_clk), .ap_rst_n(ap_rst_n),
    .awvalid(1'b0), .awprot(3'b0), .awaddr(32'b0), .wvalid(1'b0), .wdata(32'b0), .wstrb(4'b0),
    .bready(1'b0), .arvalid(1'b0), .arprot(3'b0), .araddr(32'b0), .rready(1'b0),
    .m_axis_0_tready(m_axis_0_tready), .m_axis_0_tvalid(m_axis_0_tvalid),
    .m_axis_0_tdata(m_axis_0_tdata));
endmodule
