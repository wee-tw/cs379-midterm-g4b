
#define AP_INT_MAX_W 4

#include "bnn-library.h"

// includes for network parameters
#include "slidingwindow.h"

// defines for network parameters
#define IFMChannels 16
#define Input_precision 4
#define IFMDim 32
#define SIMD 1
#define Stride 2
#define numReps 1

void DownSampler_hls_0(hls::stream<ap_uint<4> > &in0_V, hls::stream<ap_uint<4> > &out_V)
{
#pragma HLS INTERFACE axis port=in0_V
#pragma HLS INTERFACE axis port=out_V
#pragma HLS INTERFACE ap_ctrl_none port=return
ConvolutionInputGenerator_2D_kernel1<IFMChannels, Input_precision,
            IFMDim, SIMD,Stride> (in0_V, out_V, numReps);
}
