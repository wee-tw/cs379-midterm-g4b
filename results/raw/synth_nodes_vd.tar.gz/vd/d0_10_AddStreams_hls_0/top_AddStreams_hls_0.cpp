
#define AP_INT_MAX_W 10

#include "bnn-library.h"

// includes for network parameters
#include "streamtools.h"

// defines for network parameters


void AddStreams_hls_0(hls::stream<ap_uint<8>> &in0_V, hls::stream<ap_uint<8>> &in1_V,
                hls::stream<ap_uint<10>> &out_V)
{
#pragma HLS INTERFACE axis port=in0_V
#pragma HLS INTERFACE axis port=in1_V
#pragma HLS INTERFACE axis port=out_V
#pragma HLS INTERFACE ap_ctrl_none port=return
AddStreams_Batch<2, ap_uint<4>, ap_uint<4>, ap_uint<5>, 8192> (in0_V, in1_V, out_V, 1);
}
