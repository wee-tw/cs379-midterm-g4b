void DuplicateStreamsCustom(
hls::stream<ap_uint<4> > &in0,hls::stream<ap_uint<4> > &out0,hls::stream<ap_uint<4> > &out1
) {
for(unsigned int i = 0; i < 16384; i++) {
#pragma HLS PIPELINE II=1
ap_uint<4> e = in0.read();
out0.write(e);
out1.write(e);
}
}