
#define AP_INT_MAX_W 4

#include "bnn-library.h"

// includes for network parameters
#include "duplicate_impl.hpp"

// defines for network parameters


void DuplicateStreams_hls_2(hls::stream<ap_uint<4> > &in0_V,hls::stream<ap_uint<4> > &out0_V,hls::stream<ap_uint<4> > &out1_V)
{
#pragma HLS INTERFACE axis port=in0_V
#pragma HLS INTERFACE axis port=out0_V
#pragma HLS INTERFACE axis port=out1_V
#pragma HLS INTERFACE ap_ctrl_none port=return
DuplicateStreamsCustom(in0_V, out0_V,out1_V);
}
