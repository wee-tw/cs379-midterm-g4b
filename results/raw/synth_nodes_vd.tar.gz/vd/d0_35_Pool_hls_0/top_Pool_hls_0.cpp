
#define AP_INT_MAX_W 8

#include "bnn-library.h"

// includes for network parameters
#include "activations.hpp"
#include "maxpool.h"
#include "pool.hpp"

// defines for network parameters
#define Channels 64
#define PE 1
#define KernelSize 64
#define OFMDimTotal 1
#define numReps 1

void Pool_hls_0(hls::stream<ap_uint<4> > &in0_V, hls::stream<ap_uint<8> > &out_V)
{
#pragma HLS INTERFACE axis port=in0_V
#pragma HLS INTERFACE axis port=out_V
#pragma HLS INTERFACE ap_ctrl_none port=return
QuantAvgPoolFunction<ap_uint<10>,ap_uint<8>,2> pool_fxn;
Pool_batch<Channels, PE, KernelSize,Slice<ap_uint<4> >, Slice< ap_uint<8> > >
        (in0_V, out_V, pool_fxn, OFMDimTotal*numReps);
}
